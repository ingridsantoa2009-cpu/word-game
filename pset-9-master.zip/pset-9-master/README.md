chess and stuff
